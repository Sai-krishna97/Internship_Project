package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC001_URLValidation extends BaseClass{

	
	
	@Test(groups={"smoke"})
	public void verify_Url() throws InterruptedException {
		
		HomePage obj=new HomePage(driver);
		logger.info("*** home page was displayed****");
		String title=driver.getTitle();
		Assert.assertEquals(title, "Tip Calculator");
	}
}

