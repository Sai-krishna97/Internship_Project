package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC009_HomePageFormValidation extends BaseClass{
	
	@Test(priority = 1,groups= {"smoke"})
    public void verifyFormPresence() {
        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isFormDisplayed(), "Tip Calculator form should be displayed.");
    }
	
	 @Test(priority = 2,groups= {"smoke"})
	    public void verifyBillAmountLabelText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getBillAmountLabelText(), "Bill Amount:", "Bill Amount label text is incorrect.");
	    }
	 
	 @Test(priority = 3,groups= {"smoke"})
	    public void verifyServiceRatingLabelText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getServiceRatingLabelText(), "Service Rating (1 to 10):", "Service Rating label text is incorrect.");
	    }
	 
	  @Test(priority = 4,groups= {"smoke"})
	    public void verifyNumberOfPeopleLabelText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getNumberOfPeopleLabelText(), "Number of People:", "Number of People label text is incorrect.");
	    }
	  
	  @Test(priority = 5,groups= {"smoke"})
	    public void verifyCustomTipLabelText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getCustomTipLabelText(), "Custom Tip (₹):", "Custom Tip label text is incorrect.");
	    }
	  
	  @Test(priority = 6,groups= {"smoke"})
	    public void testServiceRatingValueNotWhite() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.isServiceRatingValueDisplayedAndNotWhite(), "Service rating value should be displayed and not be white.");
	    }
	  
	  @Test(priority = 7,groups= {"smoke"})
	    public void verifyCalculateButtonText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getCalculateButtonText(), "Calculate", "Calculate button text is incorrect.");
	    }
}
