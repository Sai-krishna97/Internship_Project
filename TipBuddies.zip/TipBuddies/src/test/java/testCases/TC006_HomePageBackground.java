package testCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC006_HomePageBackground extends BaseClass {

    @Test
    public void validateHomePageBackground() {
        // Validate background gradient color
        HomePage homepage = new HomePage(driver);
        WebElement body = driver.findElement(By.tagName("body"));
        String backgroundColor = body.getCssValue("background-image");
        Assert.assertTrue(backgroundColor.contains("linear-gradient(120deg, rgba(220, 214, 229, 0.847), rgb(8, 48, 118))"), "Background gradient color is not as expected.");

        // Validate font style
        WebElement textElement = driver.findElement(By.tagName("h1")); // Assuming h1 tag for text element
        String fontStyle = textElement.getCssValue("font-family");
        Assert.assertEquals(fontStyle, "Arial, sans-serif", "Font style is not as expected.");
    }

}
