package testCases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC008_HomePageApplicationName extends BaseClass{

	public final String expectedAppName = "Tip Buddies";
	
	@Test(priority = 3)
    public void verifyApplicationNameText() {
        HomePage homePage = new HomePage(driver);
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10)); // Keep a reasonable overall timeout

        // Wait for the h1 element containing the application name to be visible
        //WebElement appNameHeader = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@class='team-title']")));

        // Introduce a fixed delay to allow for the staggered animation
        try {
            Thread.sleep(2000); // Wait for 2 seconds (2000 milliseconds)
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        Assert.assertEquals(homePage.getApplicationName(), expectedAppName, "Application name text is incorrect.");
    }
}
