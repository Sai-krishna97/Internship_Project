package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC007_HomePageLogo extends BaseClass{

	
	@Test
	public void verifyLogoPresence() {
		HomePage obj=new HomePage(driver);
        Assert.assertTrue(obj.isLogoDisplayed(), "Logo should be displayed.");
    }
}
