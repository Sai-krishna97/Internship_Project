package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC028_ResultSectionBeforeAction extends BaseClass{
	@Test
	public void verifyResultSectionIsNotVisibleOnPageLoad() {
        HomePage homePage = new HomePage(driver);
        boolean isVisible = homePage.isResultSectionVisible();
        Assert.assertFalse(isVisible, "Result section should NOT be visible immediately on page load.");
    }
}
