package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC012_to_TC018_PresenceOfFields extends BaseClass{

	
	 @Test(priority = 20)
	    public void verifyBillAmountInputFieldPresence() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.billAmountInputField.isDisplayed(), "Bill Amount input field should be displayed.");
	    }
	 
	 @Test(priority = 21)
	    public void verifyServiceRatingSliderInputFieldPresence() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.scrollBar.isDisplayed(), "Service Rating slider should be displayed.");
	    }
	 
	 
	 @Test(priority = 19)
	    public void verifyDefaultServiceRatingValue() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getServiceRatingValue(), "5", "Default Service Rating value is not '5'.");
	    }
	 
	 
	 @Test(priority = 22)
	    public void verifyNumberOfPeopleInputFieldPresence() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.peopleInputField.isDisplayed(), "Number of People input field should be displayed.");
	    }
	 @Test(priority = 23)
	    public void verifyCustomTipInputFieldPresence() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.customTipField.isDisplayed(), "Custom Tip input field should be displayed.");
	    }

	    @Test(priority = 24)
	    public void verifyCalculateButtonPresence() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.calculateButton.isDisplayed(), "Calculate button should be displayed.");
	    }
}
