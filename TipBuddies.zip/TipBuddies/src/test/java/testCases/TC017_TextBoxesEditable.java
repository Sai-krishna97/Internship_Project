package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC017_TextBoxesEditable extends BaseClass{

	@Test(priority = 1)
    public void verifyBillAmountTextBoxEditable() {
        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isBillAmountTextBoxEditable(), "Bill Amount text box should be editable.");
    }
	
	@Test(priority = 2)
    public void verifyNumberOfPeopleTextBoxEditable() {
        HomePage homePage = new HomePage(driver);
        Assert.assertTrue(homePage.isNumberOfPeopleTextBoxEditable(), "Number of People text box should be editable.");
    }
	
	 @Test(priority = 3)
	    public void verifyCustomTipTextBoxEditable() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.isCustomTipTextBoxEditable(), "Custom Tip text box should be editable.");
	    }
	 
	 @Test(priority = 4)
	    public void verifyCalculateButtonEnabled() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertTrue(homePage.isCalculateButtonEnabled(), "Calculate button should be enabled.");
	    }
}
