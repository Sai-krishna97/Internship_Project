package testCases;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilities.DataProviders;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class TC029_To_TC033_ResultValidation extends BaseClass {

    @Test(dataProvider = "GetResultInputData", dataProviderClass = DataProviders.class, priority = 1,groups= {"regression"})
    public void verifyResultSectionVisibility(String amount, String people, String tip) {
        SoftAssert softAssert = new SoftAssert();
        HomePage homePage = new HomePage(driver);

        // Enter bill amount
        homePage.setAmount(amount);
        // Enter number of people
        homePage.setPeople(people);
        // Enter custom tip
        homePage.setCustomTip(tip);
        // Click calculate button
        homePage.clickCalculateButton();

        // Assert that the result section is visible
        softAssert.assertTrue(homePage.isResultSectionVisible(), "Result section is not visible");

        // Final assertion to report any failures
        softAssert.assertAll();
    }

    @Test(dataProvider = "GetResultInputData", dataProviderClass = DataProviders.class, priority = 2)
    public void verifyResultSectionDetails(String amount, String people, String tip) {
        SoftAssert softAssert = new SoftAssert();
        HomePage homePage = new HomePage(driver);

        // Enter bill amount
        homePage.setAmount(amount);
        // Enter number of people
        homePage.setPeople(people);
        // Enter custom tip
        homePage.setCustomTip(tip);
        // Click calculate button
        homePage.clickCalculateButton();

        // Validate Bill Amount Label and Value
        softAssert.assertEquals(homePage.billTitle.getText().trim(), "Bill Amount:", "Bill label text mismatch");
        String actualBill = formatToTwoDecimalPlaces(homePage.billAmount.getText().replaceAll("[^\\d.]", ""));
        String expectedBill = formatToTwoDecimalPlaces(amount);
        softAssert.assertEquals(actualBill, expectedBill, "Displayed bill does not match input");

        // Validate Tip Amount Label and Visibility
        softAssert.assertEquals(homePage.TripTitle.getText().trim(), "Tip Amount:", "Tip Amount label text mismatch");
        softAssert.assertTrue(homePage.tripAmount.isDisplayed(), "Tip amount is not visible");

        // Validate Total Amount Label and Visibility
        softAssert.assertEquals(homePage.totalTitle.getText().trim(), "Total Amount:", "Total Amount label text mismatch");
        softAssert.assertTrue(homePage.TotalAmount.isDisplayed(), "Total amount is not visible");

        // Validate Share Per Person Amount Label and Visibility
        softAssert.assertEquals(homePage.ShareTitle.getText().trim(), "Share Per Person:", "Share Per Person label text mismatch");
        softAssert.assertTrue(homePage.sharePerPersonAmount.isDisplayed(), "Share per person amount is not visible");

        // Validate Result Section Title - Text, Color, Position
        WebElement resultTitleElement = homePage.SecondaryHeading;
        softAssert.assertEquals(resultTitleElement.getText().trim(), "Tip Receipt", "Result title text mismatch");
        String expectedTitleColor = "rgba(40, 167, 69, 1)"; // From .receipt-container h2
        softAssert.assertEquals(resultTitleElement.getCssValue("color"), expectedTitleColor, "Result title color mismatch");

        // Validate Current Date at top-right
        String actualDate = homePage.currDate.getText().trim();
        String today = LocalDate.now().format(DateTimeFormatter.ofPattern("dd MMMM yyyy"));
        softAssert.assertEquals(actualDate, today, "Displayed date does not match today's date");

        // Validate 'Thank You' Footer Text, Color, Alignment
        WebElement thankYouElement = homePage.footer;
        softAssert.assertEquals(thankYouElement.getText().trim(), "Thank you for using our Tip Calculator!", "'Thank you' text mismatch");
        String expectedFooterColor = "rgba(0, 123, 255, 1)"; // From .thank-you class
        softAssert.assertEquals(thankYouElement.getCssValue("color"), expectedFooterColor, "'Thank you' color mismatch");
        String textAlign = thankYouElement.getCssValue("text-align");
        softAssert.assertEquals(textAlign, "center", "'Thank you' alignment mismatch");

        // Final assertion to report any failures
        softAssert.assertAll();
    }

    @Test(dataProvider = "RatingBasedInput", dataProviderClass = DataProviders.class, priority = 3)
    public void verifyTipCalculationBasedOnRating(String amount, String people, String ratingStr) {
        SoftAssert softAssert = new SoftAssert();
        HomePage homePage = new HomePage(driver);

        // Convert inputs to appropriate types
        double bill = Double.parseDouble(amount);
        int rating = Integer.parseInt(ratingStr);

        // Clear custom tip field to ensure rating-based calculation
        homePage.clearCustomTipField();

        // Calculate expected tip and total based on rating
        double expectedTip = (bill * rating) / 100.0;
        double expectedTotal = bill + expectedTip;

        // Set input values in the UI
        homePage.setAmount(amount);
        homePage.setPeople(people);
        homePage.setRatingSlider(ratingStr);
        // Click calculate button
        homePage.clickCalculateButton();

        // Extract actual tip and total from the UI
        String actualTip = homePage.tripAmount.getText().replaceAll("[^\\d.]", "");
        String actualTotal = homePage.TotalAmount.getText().replaceAll("[^\\d.]", "");

        // Assert that the actual tip and total match the expected values
        softAssert.assertEquals(formatToTwoDecimalPlaces(actualTip), formatToTwoDecimalPlaces(String.valueOf(expectedTip)), "Tip amount mismatch");
        softAssert.assertEquals(formatToTwoDecimalPlaces(actualTotal), formatToTwoDecimalPlaces(String.valueOf(expectedTotal)), "Total amount mismatch");

        // Final assertion to report any failures
        softAssert.assertAll();
    }

    @Test(dataProvider = "CustomTipOverrideData", dataProviderClass = DataProviders.class, priority = 4)
    public void verifyCustomTipOverridesRatingCalculation(String amount, String people, String ratingStr, String customTipStr) {
        SoftAssert softAssert = new SoftAssert();
        HomePage homePage = new HomePage(driver);

        // Convert inputs to appropriate types
        double bill = Double.parseDouble(amount);
        double customTip = Double.parseDouble(customTipStr);
        double expectedTotal = bill + customTip;

        // Set all input fields, including rating and custom tip
        homePage.setAmount(amount);
        homePage.setPeople(people);
        homePage.setRatingSlider(ratingStr);
        homePage.setCustomTip(customTipStr);
        // Click calculate button
        homePage.clickCalculateButton();

        // Fetch actual tip and total values from the UI
        String actualTip = homePage.tripAmount.getText().replaceAll("[^\\d.]", "");
        String actualTotal = homePage.TotalAmount.getText().replaceAll("[^\\d.]", "");

        // Assert that the displayed tip matches the custom tip and the total is correct
        softAssert.assertEquals(formatToTwoDecimalPlaces(actualTip), formatToTwoDecimalPlaces(String.valueOf(customTip)), "Custom Tip amount mismatch");
        softAssert.assertEquals(formatToTwoDecimalPlaces(actualTotal), formatToTwoDecimalPlaces(String.valueOf(expectedTotal)), "Total amount mismatch with custom tip");

        // Final assertion to report any failures
        softAssert.assertAll();
    }

    @Test(dataProvider = "CustomTipOverrideData", dataProviderClass = DataProviders.class, priority = 5)
    public void verifySharePerPersonCalculation(String amount, String people, String ratingStr, String customTipStr) {
        SoftAssert softAssert = new SoftAssert();
        HomePage homePage = new HomePage(driver);

        // Convert inputs to appropriate types
        double bill = Double.parseDouble(amount);
        double tipValue = Double.parseDouble(customTipStr);
        int numberOfPeople = Integer.parseInt(people);
        double total = bill + tipValue;
        double expectedShare = total / numberOfPeople;

        // Set input values in the UI
        homePage.setAmount(amount);
        homePage.setPeople(people);
        homePage.setCustomTip(customTipStr);
        // Click calculate button
        homePage.clickCalculateButton();

        // Fetch the displayed share per person amount
        String actualShare = homePage.sharePerPersonAmount.getText().replaceAll("[^\\d.]", "");

        // Assert that the actual share matches the expected share
        softAssert.assertEquals(
            formatToTwoDecimalPlaces(actualShare),
            formatToTwoDecimalPlaces(String.valueOf(expectedShare)),
            "Share Per Person amount mismatch"
        );

        // Final assertion to report any failures
        softAssert.assertAll();
    }

    // Utility method to format a numeric string to two decimal places
    private String formatToTwoDecimalPlaces(String value) {
        DecimalFormat df = new DecimalFormat("0.00");
        return df.format(Double.parseDouble(value));
    }
}