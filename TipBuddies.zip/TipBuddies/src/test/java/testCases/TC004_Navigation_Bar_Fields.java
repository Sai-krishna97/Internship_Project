package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import testBase.BaseClass;


public class TC004_Navigation_Bar_Fields extends BaseClass{
	
	@Test(groups= {"regression"})
	public void navFields_isDisplayed() {
	HomePage obj=new HomePage(driver);
	Assert.assertTrue(obj.NavigationBarFields());
	}
}
