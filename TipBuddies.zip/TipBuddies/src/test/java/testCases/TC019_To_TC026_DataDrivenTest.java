package testCases;

import java.time.Duration;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import pageObjects.HomePage;
import testBase.BaseClass;
import utilities.DataProviders;

public class TC019_To_TC026_DataDrivenTest extends BaseClass {

    @Test(dataProvider = "InputData", dataProviderClass = DataProviders.class,groups= {"regression"})
    public void inputFieldsValidation(String billAmount, String noOfPeople, String customTip) {

        HomePage obj = new HomePage(driver);

        obj.setAmount(billAmount);
        obj.setPeople(noOfPeople);
        obj.setCustomTip(customTip);
        obj.clickCalculateButton();

        try {
            if (billAmount.matches("[0-9]+") && Long.parseLong(billAmount) > 0 && Long.parseLong(billAmount) <= 1000000000) {
                if (noOfPeople.matches("[0-9]+") && Long.parseLong(noOfPeople) > 0 && Long.parseLong(noOfPeople) <= 1000000000 && !noOfPeople.contains(".")) {
                    if (customTip.isEmpty() || (customTip.matches("[0-9]*") && Long.parseLong(customTip) >= 0 && Long.parseLong(customTip) <= 1000000000)) {
                        Assert.assertTrue(true, "contains valid values");
                    } else {
                        handleAlert("Please enter a valid custom tip amount.");
                    }
                } else {
                    handleAlert("Please enter a valid number of people.");
                }
            } else {
                handleAlert("Please enter a valid bill amount.");
            }
        } catch (NumberFormatException e) {
            Assert.assertTrue(true, "contains valid values");
        }
    }

    private void handleAlert(String expectedAlertText) {
        try {
            Thread.sleep(3000); // Wait for the alert to appear
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            SoftAssert sftAss = new SoftAssert();
            sftAss.assertTrue(alertText.equalsIgnoreCase(expectedAlertText));
            System.out.println(alertText);
            alert.accept();
        } catch (NoAlertPresentException e) {
            logger.info("No alert is present");
            Assert.fail("No alert is displayed irrespective of incorrect result");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
