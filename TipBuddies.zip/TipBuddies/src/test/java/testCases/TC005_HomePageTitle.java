package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC005_HomePageTitle extends BaseClass{
	@Test
	 public void verifyHomePageTitle() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(driver.getTitle(), "Tip Calculator", "Home page title does not match the expected value.");
	    }
}
