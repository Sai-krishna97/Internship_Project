package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC012_MandatoryRequired extends BaseClass{

	 @Test(priority = 1)
	    public void verifyNumberOfPeopleIsMandatory() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertNotNull(homePage.getNumberOfPeopleRequiredAttribute(), "'required' attribute should be present on the 'Number of People' TextBox.");
	        Assert.assertEquals(homePage.getNumberOfPeopleRequiredAttribute(), "true", "'required' attribute value should be 'true' on the 'Number of People' TextBox.");
	        System.out.println("'required' attribute is present on the 'Number of People' TextBox.");
	    }
}
