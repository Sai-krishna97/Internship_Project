package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import testBase.BaseClass;

public class TC003_Navigation_Bar_visibility extends BaseClass{

	@Test
	public void navbar_isDisplayed() {
		
		HomePage obj=new HomePage(driver);
		Assert.assertTrue(obj.NavigationBarDisplayed());
	}
}
