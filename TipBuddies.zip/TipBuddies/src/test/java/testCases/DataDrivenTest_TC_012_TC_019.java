package testCases;

import org.testng.annotations.Test;

import utilities.DataProviders;

public class DataDrivenTest_TC_012_TC_019 {

	@Test(dataProvider="InputData", dataProviderClass=DataProviders.class)
	public void inputFieldsValidation(String billAmount,String noOfPeople,String customTip) {
		
	}
}
