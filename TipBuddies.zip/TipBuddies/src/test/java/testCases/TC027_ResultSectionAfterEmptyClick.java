package testCases;

import org.openqa.selenium.Alert;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC027_ResultSectionAfterEmptyClick extends BaseClass{
	WebDriverWait wait;
    @Test
    public void verifyResultSectionAfterClickWithoutInput() {
        HomePage homePage = new HomePage(driver);
        homePage.clickCalculateButton();
            Alert alert = driver.switchTo().alert();
            Assert.assertEquals(alert.getText(), "Please enter a valid bill amount."); // Verify the alert message
            alert.accept(); // Click "OK" on the alert
        boolean isVisible = homePage.isResultSectionVisible();
        Assert.assertFalse(isVisible, "Result section should NOT be visible after clicking 'Calculate' with no input.");
    }
}
