package testCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pageObjects.HomePage;
import testBase.BaseClass;

public class TC009_HomePagePlaceHolder extends BaseClass{

	
	@Test(priority = 1)
    public void verifyBillAmountPlaceholderText() {
        HomePage homePage = new HomePage(driver);
        Assert.assertEquals(homePage.getBillAmountPlaceholder(), "Enter bill amount", "Bill Amount placeholder text is incorrect.");
    }
	
	 @Test(priority = 2)
	    public void verifyNumberOfPeoplePlaceholderText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getNumberOfPeoplePlaceholder(), "Enter number of people", "Number of People placeholder text is incorrect.");
	    }

	 @Test(priority = 3)
	    public void verifyCustomTipPlaceholderText() {
	        HomePage homePage = new HomePage(driver);
	        Assert.assertEquals(homePage.getCustomTipPlaceholder(), "Enter custom tip amount (optional)", "Custom Tip placeholder text is incorrect.");
	    }
	
}
