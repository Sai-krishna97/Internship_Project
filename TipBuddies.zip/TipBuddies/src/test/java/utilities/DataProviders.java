package utilities;

import java.io.IOException;

import org.testng.annotations.DataProvider;

public class DataProviders {

	//DataProvider 1
	
	@DataProvider(name="InputData")
	public String [][] getData() throws IOException
	{
		String path=".\\testData\\InsertData1.xlsx";//taking xl file from testData
		
		ExcelUtility xlutil=new ExcelUtility(path);//creating an object for XLUtility
		
		int totalrows=xlutil.getRowCount("datasheet");	
		int totalcols=xlutil.getCellCount("datasheet",1);
				
		String inputdata[][]=new String[totalrows][totalcols];//created for two dimension array which can store the data user and password
		
		for(int i=1;i<=totalrows;i++)  //1   //read the data from xl storing in two deminsional array
		{		
			for(int j=0;j<totalcols;j++)  //0    i is rows j is col
			{
				inputdata[i-1][j]= xlutil.getCellData("datasheet",i, j);  //1,0
			}
		}
	return inputdata;//returning two dimension array
				
	}
	
	@DataProvider(name="GetResultInputData")
	public String [][] getDataForResult() throws IOException
	{
		String path=".\\testData\\InsertData1.xlsx";//taking xl file from testData
		
		ExcelUtility xlutil=new ExcelUtility(path);//creating an object for XLUtility
		
		int totalrows=xlutil.getRowCount("Sheet1");	
		int totalcols=xlutil.getCellCount("Sheet1",1);
				
		String inputdata[][]=new String[totalrows][totalcols];//created for two dimension array which can store the data user and password
		
		for(int i=1;i<=totalrows;i++)  //1   //read the data from xl storing in two deminsional array
		{		
			for(int j=0;j<totalcols;j++)  //0    i is rows j is col
			{
				inputdata[i-1][j]= xlutil.getCellData("Sheet1",i, j);  //1,0
			}
		}
	return inputdata;//returning two dimension array
				
	}
	@DataProvider(name = "RatingBasedInput")
	public String[][] getRatingBasedInput() throws IOException {
	    String path = ".\\testData\\InsertData1.xlsx"; // using the same Excel file
	    ExcelUtility xlutil = new ExcelUtility(path);

	    int totalRows = xlutil.getRowCount("Sheet2");	
	    int totalCols = xlutil.getCellCount("Sheet2", 1);

	    String ratingData[][] = new String[totalRows][totalCols];

	    for (int i = 1; i <= totalRows; i++) {
	        for (int j = 0; j < totalCols; j++) {
	            ratingData[i - 1][j] = xlutil.getCellData("Sheet2", i, j);
	        }
	    }

	    return ratingData;
	}
	
	@DataProvider(name = "CustomTipOverrideData")
	public String[][] getCustomTipOverrideData() throws IOException {
	    String path = ".\\testData\\InsertData1.xlsx"; // using the same Excel file
	    ExcelUtility xlutil = new ExcelUtility(path);

	    int totalRows = xlutil.getRowCount("Sheet3");	
	    int totalCols = xlutil.getCellCount("Sheet3", 1);

	    String ratingData[][] = new String[totalRows][totalCols];

	    for (int i = 1; i <= totalRows; i++) {
	        for (int j = 0; j < totalCols; j++) {
	            ratingData[i - 1][j] = xlutil.getCellData("Sheet3", i, j);
	        }
	    }

	    return ratingData;
	}
	
	
}

