package pageObjects;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class HomePage extends BasePage{
	
	public HomePage(WebDriver driver){
		super(driver);
	}

	@FindBy(className= "logo")
	public WebElement logo;
	
	@FindBy(className="team-title") 
	WebElement Title;
	
	@FindBy(id="billAmount") 
	public WebElement billAmountInputField;
	
	@FindBy(id="numPeople")
	public WebElement peopleInputField;
	
	@FindBy(xpath="//input[@id='customTip']")
	public WebElement customTipField;
	
	@FindBy(xpath="//button[text()='Calculate']")
	public WebElement calculateButton;
	
	@FindBy(xpath="//*[@id=\"serviceRating\"]")
	public WebElement scrollBar;
	
	
	@FindBy(xpath = "//*[@id='receiptContainer']")
    WebElement resultSection;
	
	
	@FindBy(xpath="//*[@id='receiptContainer']/div[1]/h2")
	public WebElement SecondaryHeading;
	
	@FindBy(xpath="//span[@id=\"currentDate\"]")
	public WebElement currDate;
	
	@FindBy(xpath="//p[@class=\"thank-you\"]")
	public WebElement footer;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[1]")
	public WebElement billTitle;
	
	@FindBy(xpath="//*[@id=\"receiptBillAmount\"]")
	public WebElement billAmount;
	
	@FindBy(xpath="//*[@id='receiptContainer']/div[2]/span[3]")
	public WebElement TripTitle;
	
	@FindBy(xpath="//span[@id='receiptTipAmount']")
	public WebElement tripAmount;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[5]")
	public WebElement totalTitle;
	
	@FindBy(id="receiptTotalAmount")
	public WebElement TotalAmount;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[7]")
	public WebElement ShareTitle;
	
	@FindBy(id="receiptSharePerPerson")
	public WebElement sharePerPersonAmount;
	
	@FindBy(id="navbar")
	WebElement navBar;
	
	@FindBy(tagName="a")
	List<WebElement>links;
	
	@FindBy(tagName="form")
    public WebElement form;
	
	//labels
	
	@FindBy(xpath="//label[@for=\"billAmount\"]")
    public WebElement billAmount_label;
	
	@FindBy(xpath="//label[@for='serviceRating']")
    public WebElement serviceRating_label;
	
	
	@FindBy(xpath="//label[@for='numPeople']")
    public WebElement numberOfPeople_label;
	
	
	@FindBy(xpath="//label[@for='customTip']")
    public WebElement customTip_label;
	
	
	//Service Rating Value
  @FindBy(xpath="//span[@id=\"serviceValue\"]")
  public WebElement serviceRating_value;
	

    
    
    //labels validation 
    
    public String getBillAmountLabelText() {
        return billAmount_label.getText().trim();
    }
    
    public String getServiceRatingLabelText() {
        return serviceRating_label.getText().trim();
    }
    
    public String getNumberOfPeopleLabelText() {
        return numberOfPeople_label.getText().trim();
    }
    
    
    public String getCustomTipLabelText() {
        return customTip_label.getText().trim();
    }
    
    public String getCalculateButtonText() {
        return calculateButton.getText().trim();
    }
    
    public String getApplicationName() {
        return Title.getText().trim(); // Get text from the parent h1
    }
    
    //place holder validation
    
    public String getBillAmountPlaceholder() {
        return billAmountInputField.getAttribute("placeholder");
    }
    
    
    public String getNumberOfPeoplePlaceholder() {
        return peopleInputField.getAttribute("placeholder");
    }
    
    public String getCustomTipPlaceholder() {
        return customTipField.getAttribute("placeholder");
    }
 
    
    //enability verification
    
    public boolean isBillAmountTextBoxEditable() {
        String readOnly = billAmountInputField.getAttribute("readonly");
        return readOnly == null || readOnly.equalsIgnoreCase("false");
    }
    
    public boolean isNumberOfPeopleTextBoxEditable() {
        String readOnly = peopleInputField.getAttribute("readonly");
        return readOnly == null || readOnly.equalsIgnoreCase("false");
    }
    
    
    public boolean isCustomTipTextBoxEditable() {
        String readOnly =customTipField.getAttribute("readonly");
        return readOnly == null || readOnly.equalsIgnoreCase("false");
    }
    
    public boolean isCalculateButtonEnabled() {
        return calculateButton.isEnabled();
    }
    
    
    //mandatory validation
    
    public String getNumberOfPeopleRequiredAttribute() {
        return peopleInputField.getAttribute("required");
    }
    
    public boolean isLogoDisplayed() {
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        return logo.isDisplayed();
    }
    
    
    public String getServiceRatingValue() {
        return serviceRating_value.getText().trim();
    }
    
    //actions methods
    
    
    public boolean isFormDisplayed() {
        return form.isDisplayed();
    }
	
	public void setAmount(String amount) {
		billAmountInputField.clear();
		billAmountInputField.sendKeys(amount);
	}
	
	public void setPeople(String people) {
		peopleInputField.clear();
		peopleInputField.sendKeys(people);
	}
	public void setCustomTip(String tip) {
		customTipField.clear();
		customTipField.sendKeys(tip);
	}
	
	public void clickCalculateButton() {
		calculateButton.click();
	}
	
	
	public boolean NavigationBarDisplayed() {
		try {
			navBar.isDisplayed();
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public boolean NavigationBarFields() {
		try {
			if(links.isEmpty()) {return false;}
			for(WebElement ele:links) {
				if(!(ele.isDisplayed())) {
					return false;
				}
			}
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	
	public boolean isServiceRatingValueDisplayedAndNotWhite() {
        try {
            String color = serviceRating_value.getCssValue("color");
            // You might need to adjust the color format comparison based on what Selenium returns
            // It could be rgba(255, 255, 255, 1), rgb(255, 255, 255), or even a color name.
            // This example checks for common white color formats.
            return serviceRating_value.isDisplayed() &&
                   !color.contains("rgba(255, 255, 255") &&
                   !color.contains("rgb(255, 255, 255") &&
                   !color.equalsIgnoreCase("white");
        } catch (Exception e) {
            return false;
        }
    }
	
	 public boolean isResultSectionVisible() {
	        return resultSection.isDisplayed();
	    }

	    public void handleAlertIfPresent() {
	        try {
	            Alert alert = driver.switchTo().alert();
	            alert.accept(); // Or alert.dismiss() depending on the application's behavior
	        } catch (Exception e) {
	            // No alert appeared, continue
	            Assert.fail("Alert was not present as expected.");
	        }
	    }

	    public void clearCustomTipField() {
	        customTipField.clear();
	    }

	    public void setRatingSlider(String ratingValue) {
	        ((JavascriptExecutor) driver).executeScript("arguments[0].value='" + ratingValue + "';", scrollBar);
	        ((JavascriptExecutor) driver).executeScript("arguments[0].dispatchEvent(new Event('input'))", scrollBar);
	    }
}
