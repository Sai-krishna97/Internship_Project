package pageObjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage extends BasePage{
	
	public HomePage(WebDriver driver){
		super(driver);
	}

	@FindBy(className="logo") 
	WebElement logo;
	
	@FindBy(className="team-title") 
	WebElement Title;
	
	@FindBy(id="billAmount") 
	WebElement billAmountInputField;
	
	@FindBy(css="input#[placeholder='Enter number of people']")
	WebElement peopleInputField;
	
	@FindBy(xpath="//input[@id='customTip']")
	WebElement customTipField;
	
	@FindBy(xpath="//button[text()='Calculate']")
	WebElement calculateButton;
	
	@FindBy(xpath="//input[id=\"serviceRating\"]")
	WebElement scrollBar;
	
	@FindBy(xpath="//*[@id='receiptContainer']/div[1]/h2")
	WebElement SecondaryHeading;
	
	@FindBy(xpath="//span[id=\"currentDate\"]")
	WebElement currDate;
	
	@FindBy(xpath="//p[class=\"thank-you\"]")
	WebElement footer;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[1]")
	WebElement billTitle;
	
	@FindBy(xpath="//span[id='receiptBillAmount']")
	WebElement billAmount;
	
	@FindBy(xpath="//*[@id='receiptContainer']/div[2]/span[3]")
	WebElement TripTitle;
	
	@FindBy(xpath="//span[@id='receiptTipAmount']")
	WebElement tripAmount;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[5]")
	WebElement totalTitle;
	
	@FindBy(id="receiptTotalAmount")
	WebElement TotalAmount;
	
	@FindBy(xpath="//*[@id=\"receiptContainer\"]/div[2]/span[7]")
	WebElement ShareTitle;
	
	@FindBy(id="receiptSharePerPerson")
	WebElement sharePerPersonAmount;
	
	@FindBy(id="navbar")
	WebElement navBar;
	
	@FindBy(tagName="a")
	List<WebElement>links;
	
	
	public void setAmount(String amount) {
		billAmountInputField.click();
		billAmountInputField.sendKeys(amount);
	}
	
	public void setPeople(String people) {
		peopleInputField.click();
		peopleInputField.sendKeys(people);
	}
	public void setCustomTip(String tip) {
		customTipField.click();
		customTipField.sendKeys(tip);
	}
	
	public void clickCalculateButton() {
		calculateButton.click();
	}
	
	public boolean NavigationBarDisplayed() {
		try {
			navBar.isDisplayed();
		}catch(Exception e) {
			return false;
		}
		return true;
	}
	
	public boolean NavigationBarFields() {
		try {
			if(links.isEmpty()) {return false;}
			for(WebElement ele:links) {
				if(!(ele.isDisplayed())) {
					return false;
				}
			}
		}catch(Exception e) {
			return false;
		}
		return true;
	}
}
